package ed3s6_p2p1;

import java.util.Scanner;

/**
 *
 * @author Rodriguez
 */
public class ED3S6_P2P1 {
    
    public ED3S6_P2P1(int n) {
        System.out.println("(x+y)^" + n + " = " + formula(n, 0));
    }

    private String formula(int n, int k) {
        if (k > n) {
            return "";
        } else {
            int factor = factorial(n) / (factorial(k) * factorial(n - k));
            String termino = "";
            if (factor > 1) {
                termino = termino + factor;
            }
            termino = termino + letra("x", n - k) + letra("y", k);
            if (termino.equals("")) {
                termino = "1";
            }
            if (k < n) {
                termino = termino + "+";
            }
            return termino + formula(n, k + 1);
        }
    }

    private String letra(String variable, int exp) {
        if (exp == 0) {
            return "";
        } else if (exp == 1) {
            return variable;
        } else {
            return variable + "^" + exp;
        }
    }

    private int factorial (int a){
      int fac=1;
      if(a==0 || a==1) return 1;
      else if (a>1)   fac= a*factorial(a-1);
      return fac;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("A qué potencia: ");
        int n = sc.nextInt();
        new ED3S6_P2P1(n);
    } 
}
